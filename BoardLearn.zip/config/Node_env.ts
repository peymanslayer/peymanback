import * as dotenv from 'dotenv'
dotenv.config()

export const mode ={
    mode:process.env.NODE_ENV,
    
}