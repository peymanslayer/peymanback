
export interface IError{
    statusCode:number,
    message:string,
    isOperational:true,
    status:number,
    name:string
}